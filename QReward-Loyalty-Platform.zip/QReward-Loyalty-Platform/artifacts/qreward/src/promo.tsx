import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useCompleteOnboarding } from "@workspace/api-client-react";
import "./promo.css";

const asset = (path: string) =>
  `${import.meta.env.BASE_URL}reference/assets/${path}`;

function smoothAnchor(event: React.MouseEvent<HTMLAnchorElement>) {
  const href = event.currentTarget.getAttribute("href");
  if (!href?.startsWith("#")) return;

  const target = document.getElementById(href.slice(1));
  if (!target) return;

  event.preventDefault();
  target.scrollIntoView({ behavior: "smooth", block: "start" });
  window.history.replaceState(null, "", href);
}

const cardTypes = [
  ["stamps.png", "Stamps", "Works on the mechanics: Buy 10 and get the 11th as a gift"],
  ["cashback.png", "Cashback", "Give and redeem customers points for purchases"],
  ["reward.png", "Reward", "Classic discount system with several earning levels."],
  ["membership.png", "Membership", "Attract new customers with digital coupons."],
  ["discount.png", "Discount", "Classic discount system with several earning levels."],
  ["coupon.png", "Coupon", "Attract new customers with digital coupons."],
  ["multipass.png", "Multipass", "Sell services in bulk to your customers"],
  ["gift-card.png", "Gift card", "Sell prepaid gift cards to customers"],
];

const pushCards = [
  ["Transaction", "Automatic PUSH notifications with the transaction information is sent instantly at the time of sale. The message informs the client about their current loyalty and reward status.", "You have earned 62 points", "Thank you for your purchase. We are waiting for you to visit again. 🤗"],
  ["Marketing", "Notifications can be sent manually like SMS. Send PUSH messages to your entire customer base or a selected group.", "Bagels are now in stock", "The all-new bagels 🍩 in our bakeries are avaliable right now. Catch this ⚡"],
  ["Geolocation", "Automatic PUSH messages are automatically sent out when any loyalty customer is within 330 feet of your business location.", "👀 I see you're close by", "Today, save 50% on coffee to go. We would also like to remind you that every 10th coffee is free ☕"],
  ["Quality control", "Automatic PUSH are automatically sent 1 hour after purchase. Clients are invited to leave feedback on the service quality.", "Thank you for your visit!", "Rate the quality of service using the link in the card description 👉"],
  ["Reminder", "Automatic PUSH messages are automatically sent 28 days after the last purchase. This is to remind the customer to come back to see you again. Reminder time is configurable.", "We miss you", "Sign up for a visit using the link in the card description 📅"],
  ["Create your way", "The PUSH designer allows you to create your own script for sending automatic PUSHs. The number of messages and scenarios is not limited.", "Your headline", "And some description with emojies 🎸"],
];

function PromoHeader() {
  return (
    <header className="promo-header">
      <div className="promo-container promo-header-inner">
        <Link href="/" className="promo-logo" data-testid="promo-logo">
          <img src={asset("qreward-logo.png")} alt="" />
          <span>QReward</span>
        </Link>
        <nav className="promo-nav" aria-label="Main navigation">
          <a href="#card-types" onClick={smoothAnchor}>Card types</a>
          <a href="#scanner-app" onClick={smoothAnchor}>Scanner App</a>
          <a href="#push" onClick={smoothAnchor}>Push</a>
          <a href="#pricing" onClick={smoothAnchor}>Pricing</a>
          <a href="#automations" onClick={smoothAnchor}>Automations</a>
          <a href="#join" onClick={smoothAnchor}>Join</a>
        </nav>
        <Link href="/signup" className="promo-button promo-button-small" data-testid="promo-header-signup">
          Sign up now
        </Link>
      </div>
    </header>
  );
}

function PromoButton({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link className="promo-button" href={href}>
      {children}
    </Link>
  );
}

function PhoneStack() {
  return (
    <div className="promo-phone-stack" aria-label="Digital reward card preview">
      <img className="promo-phone promo-phone-back" src={asset("hero-2.jpg")} alt="" />
      <img className="promo-phone promo-phone-front" src={asset("hero-1.jpg")} alt="" />
    </div>
  );
}

function PromoLanding() {
  return (
    <div className="promo-page">
      <PromoHeader />
      <main>
        <section className="promo-section promo-hero">
          <div className="promo-container promo-hero-grid">
            <div className="promo-hero-copy">
              <h1>The simplest rewards program for local businesses</h1>
              <p>Get a 2X increase in return rates and a 30% increase in revenue with our digital reward cards.</p>
              <div className="promo-actions">
                <PromoButton href="/signup">Sign up free</PromoButton>
                <a className="promo-button" href="#join" onClick={smoothAnchor}>Book a demo</a>
              </div>
              <p className="promo-trial">14-day free trial</p>
              <div className="promo-wallets">
                <img src={asset("apple-pay.svg")} alt="Apple Pay" />
                <img src={asset("google-pay.svg")} alt="Google Pay" />
              </div>
            </div>
            <PhoneStack />
          </div>
        </section>

        <section className="promo-section promo-light promo-card-types-section" id="card-types">
          <div className="promo-container">
            <div className="promo-centered-heading">
              <h2>Multiple Card Types</h2>
              <p>Our simple card builder has many card types to choose from</p>
              <small>all cards are fully customizable (logo, colors, icons, text, etc)</small>
            </div>
            <div className="promo-card-grid">
              {cardTypes.map(([image, title, description]) => (
                <article className="promo-card-type" key={title}>
                  <img src={asset(`cards/${image}`)} alt={`${title}: ${description}`} />
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="promo-section promo-dark promo-scanner" id="scanner-app">
          <div className="promo-container promo-split">
            <div>
              <h2>Scan customer cards with our free Scanner App</h2>
              <p className="promo-lead">No additional hardware is required with our platform</p>
              <p>Once you've created a business account, you'll receive a link to install the free card scanner app. Simply share the app with every salesperson in your business and monitor shared statistics</p>
              <a className="promo-button" href="#join" onClick={smoothAnchor}>Scanner App</a>
            </div>
            <img className="promo-scanner-image" src={asset("scanner-app/scanner-app-seller.png")} alt="Scanner App" />
          </div>
        </section>

        <section className="promo-section promo-light promo-push" id="push">
          <div className="promo-container">
            <div className="promo-centered-heading">
              <h2>Send push notifications to increase customer retention</h2>
              <p>Totally free &amp; unlimited</p>
            </div>
            <div className="promo-push-grid">
              {pushCards.map(([title, description, notificationTitle, notificationBody]) => (
                <article className="promo-push-card" key={title}>
                  <div className="promo-notification">
                    <div className="promo-notification-top"><b>YOUR COMPANY</b><span>now</span></div>
                    <strong>{notificationTitle}</strong>
                    <p>{notificationBody}</p>
                  </div>
                  <h3>{title}</h3>
                  <p>{description}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="promo-section promo-dark" id="pricing">
          <div className="promo-container">
            <div className="promo-centered-heading">
              <h2>Pricing</h2>
              <p>Choose the plan that fits the way you grow.</p>
            </div>
            <div className="promo-pricing-grid">
              <article className="promo-price-card">
                <p className="promo-plan-label">For getting started</p>
                <h3>Beginner</h3>
                <strong>Free <span>/ forever</span></strong>
                <ul><li>1 loyalty promotion</li><li>1 location</li><li>Unlimited digital cards</li><li>Basic customer insights</li></ul>
                <PromoButton href="/signup">Start free</PromoButton>
              </article>
              <article className="promo-price-card promo-price-card-featured">
                <p className="promo-plan-label">For growing businesses</p>
                <h3>Business</h3>
                <strong>$49 <span>/ month</span></strong>
                <ul><li>5 loyalty promotions</li><li>3 locations</li><li>Unlimited digital cards</li><li>Push notifications</li><li>Customer insights</li></ul>
                <PromoButton href="/signup">Start free trial</PromoButton>
              </article>
              <article className="promo-price-card">
                <p className="promo-plan-label">For ambitious teams</p>
                <h3>Growth</h3>
                <strong>$149 <span>/ month</span></strong>
                <ul><li>Unlimited promotions</li><li>10 locations</li><li>Team access</li><li>Automated campaigns</li><li>API access</li></ul>
                <PromoButton href="/signup">Start free trial</PromoButton>
              </article>
            </div>
          </div>
        </section>

        <section className="promo-section promo-light promo-automations" id="automations">
          <div className="promo-container promo-split">
            <div>
              <h2>Automate your workflow</h2>
              <p className="promo-lead">Integrate with 5,000+ apps, infinite possibilities</p>
              <a className="promo-button" href="#join" onClick={smoothAnchor}>Learn more</a>
            </div>
            <img src={asset("automations.svg")} alt="Automations" />
          </div>
        </section>

        <section className="promo-section promo-dark promo-value promo-last-section" id="join">
          <div className="promo-container">
            <div className="promo-centered-heading">
              <h2>Make every customer count</h2>
              <p>Turn first visits into lasting loyalty with digital rewards that feel personal.</p>
            </div>
            <div className="promo-benefit-grid">
              <article className="promo-benefit"><span>01</span><h3>Launch in minutes</h3><p>Create a beautiful loyalty card without extra hardware or a complicated setup.</p></article>
              <article className="promo-benefit"><span>02</span><h3>Bring customers back</h3><p>Give regulars a reason to return with timely rewards and friendly reminders.</p></article>
              <article className="promo-benefit"><span>03</span><h3>Grow with clarity</h3><p>See what customers love, then make confident decisions for your next offer.</p></article>
            </div>
            <div className="promo-actions promo-actions-centered">
              <PromoButton href="/signup">Sign up free</PromoButton>
              <a className="promo-button" href="mailto:hello@qreward.demo">Book a demo</a>
            </div>
            <p className="promo-trial">14-day free trial</p>
          </div>
        </section>
      </main>
      <footer className="promo-footer">
        <div className="promo-container promo-footer-inner">
          <strong>© 2026, QReward. All Rights Reserved.</strong>
          <div><a href="mailto:hello@qreward.demo">hello@qreward.demo</a><a href="/privacy">Privacy policy ↗</a><a href="/terms">Subscription agreement ↗</a></div>
          <span>English (International)</span>
        </div>
      </footer>
    </div>
  );
}

function SignupField({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  required = true,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <label className="promo-field">
      <span>{label}</span>
      <input required={required} type={type} value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} />
    </label>
  );
}

function PromoSignup() {
  const complete = useCompleteOnboarding();
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    businessName: "",
    email: "",
    phone: "",
    country: "Austria",
    currency: "EUR",
    programName: "The Everyday Card",
    rewardDescription: "A free drink of your choice",
    stampTarget: "10",
  });
  const update = (key: keyof typeof form) => (value: string) => setForm((current) => ({ ...current, [key]: value }));

  return (
    <div className="promo-signup-page">
      <div className="promo-signup-brand">
        <Link href="/" className="promo-logo"><img src={asset("qreward-logo.png")} alt="" /><span>QReward</span></Link>
        <p>Digital loyalty platform<br />based on Apple Wallet<br />and Google Wallet</p>
      </div>
      <div className="promo-signup-topbar"><Link href="/login">Login</Link><strong>Registration</strong></div>
      <main className="promo-signup-card">
        <p className="promo-kicker">14-day free trial</p>
        <h1>Start Your 14 Day Free Trial Today!</h1>
        <div className="promo-stepper"><span className={step === 1 ? "active" : "done"}>Step 1<br /><b>Tell Us About Your Business</b></span><span className={step === 2 ? "active" : ""}>Step 2<br /><b>Trial Details</b></span></div>
        <form onSubmit={(event) => {
          event.preventDefault();
          if (step === 1) { setStep(2); return; }
          complete.mutate({
            data: {
              businessName: form.businessName,
              businessType: "OTHER",
              country: form.country,
              currency: form.currency,
              timezone: "Europe/Vienna",
              programName: form.programName,
              programType: "STAMP",
              stampTarget: Number(form.stampTarget),
              rewardDescription: form.rewardDescription,
            },
          }, { onSuccess: (result) => setLocation(`/dashboard/programs/${result.program.id}/designer`) });
        }} className="promo-signup-form">
          {step === 1 ? <>
            <SignupField label="Business name" value={form.businessName} onChange={update("businessName")} placeholder="Your business name" />
            <SignupField label="Business email" value={form.email} onChange={update("email")} type="email" placeholder="you@yourbusiness.com" />
            <SignupField label="Phone number" value={form.phone} onChange={update("phone")} placeholder="+43" required={false} />
            <div className="promo-form-row"><SignupField label="Country" value={form.country} onChange={update("country")} /><SignupField label="Currency" value={form.currency} onChange={update("currency")} /></div>
          </> : <>
            <SignupField label="First loyalty programme name" value={form.programName} onChange={update("programName")} />
            <SignupField label="Your reward" value={form.rewardDescription} onChange={update("rewardDescription")} />
            <SignupField label="Stamps to earn" value={form.stampTarget} onChange={update("stampTarget")} type="number" />
          </>}
          {complete.isError && <p className="promo-form-error">We could not create your workspace. Please check the details and try again.</p>}
          <button className="promo-button promo-submit" type="submit" disabled={complete.isPending}>{complete.isPending ? "Creating your workspace…" : step === 1 ? "Continue" : "Start free trial"}</button>
        </form>
        <p className="promo-signup-legal">By continuing, you agree to receive loyalty product updates.</p>
      </main>
    </div>
  );
}

export { PromoLanding, PromoSignup };