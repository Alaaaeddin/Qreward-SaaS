import { Router, type IRouter } from "express";
import healthRouter from "./health";
import qrewardRouter from "./qreward";

const router: IRouter = Router();

router.use(healthRouter);
router.use(qrewardRouter);

export default router;
