import { randomUUID } from "node:crypto";
import { and, count, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import {
  analyticsEventsTable,
  businessMembersTable,
  businessesTable,
  customerProgramsTable,
  customersTable,
  loyaltyProgramsTable,
  locationsTable,
  profilesTable,
  rewardsTable,
  transactionsTable,
} from "@workspace/db";
import {
  CompleteOnboardingBody,
  CreateCustomerBody,
  CreateProgramBody,
  CreateTransactionBody,
  GetAnalyticsQueryParams,
  GetBusinessResponse,
  GetCustomerParams,
  GetDashboardActivityQueryParams,
  GetDashboardSummaryQueryParams,
  GetProgramParams,
  GetSessionResponse,
  ListCustomersQueryParams,
  ListProgramsResponse,
  ListTransactionsQueryParams,
  RedeemRewardParams,
  UpdateBusinessBody,
  UpdateProgramBody,
  UpdateProgramParams,
  ValidateScanBody,
} from "@workspace/api-zod";
import {
  demoIds,
  ensureDemoData,
  getDemoBusiness,
  getDemoProgram,
} from "../lib/qreward-demo";

const router: IRouter = Router();

const iso = (value: Date | null | undefined) =>
  value ? value.toISOString() : null;

async function businessDto() {
  const business = await getDemoBusiness();
  if (!business) {
    return null;
  }
  const [[locationsRow], [activeProgramsRow]] = await Promise.all([
    db
      .select({ value: count() })
      .from(locationsTable)
      .where(eq(locationsTable.businessId, demoIds.business)),
    db
      .select({ value: count() })
      .from(loyaltyProgramsTable)
      .where(
        and(
          eq(loyaltyProgramsTable.businessId, demoIds.business),
          eq(loyaltyProgramsTable.active, true),
        ),
      ),
  ]);

  return {
    id: business.id,
    name: business.name,
    slug: business.slug,
    logoUrl: business.logoUrl,
    email: business.email,
    phone: business.phone,
    website: business.website,
    city: business.city,
    country: business.country,
    timezone: business.timezone,
    currency: business.currency,
    subscriptionStatus: business.subscriptionStatus,
    locations: Number(locationsRow?.value ?? 0),
    activePrograms: Number(activeProgramsRow?.value ?? 0),
  };
}

async function programDto(program: typeof loyaltyProgramsTable.$inferSelect) {
  const [{ value: customerCount }] = await db
    .select({ value: count() })
    .from(customerProgramsTable)
    .where(eq(customerProgramsTable.programId, program.id));

  return {
    id: program.id,
    businessId: program.businessId,
    name: program.name,
    description: program.description,
    type: program.type,
    active: program.active,
    status: program.status,
    primaryColor: program.primaryColor,
    secondaryColor: program.secondaryColor,
    backgroundColor: program.backgroundColor,
    customerCount: Number(customerCount),
    rewardDescription: program.rewardDescription,
    stampTarget: program.stampTarget,
    pointsTarget: program.pointsTarget,
    createdAt: program.createdAt.toISOString(),
  };
}

function customerDto(customer: typeof customersTable.$inferSelect) {
  return {
    id: customer.id,
    businessId: customer.businessId,
    firstName: customer.firstName,
    lastName: customer.lastName,
    email: customer.email,
    phone: customer.phone,
    status: customer.status,
    totalVisits: customer.totalVisits,
    totalSpend: Number(customer.totalSpend),
    lastVisitAt: iso(customer.lastVisitAt),
    joinedAt: customer.createdAt.toISOString(),
    avatarUrl: null,
  };
}

function rewardDto(reward: typeof rewardsTable.$inferSelect) {
  return {
    id: reward.id,
    customerId: reward.customerId,
    programId: reward.programId,
    name: reward.name,
    description: reward.description,
    status: reward.status,
    earnedAt: reward.earnedAt.toISOString(),
    redeemedAt: iso(reward.redeemedAt),
  };
}

async function transactionDto(transaction: typeof transactionsTable.$inferSelect) {
  const [[customer], [program]] = await Promise.all([
    db
      .select({ firstName: customersTable.firstName, lastName: customersTable.lastName })
      .from(customersTable)
      .where(eq(customersTable.id, transaction.customerId))
      .limit(1),
    db
      .select({ name: loyaltyProgramsTable.name })
      .from(loyaltyProgramsTable)
      .where(eq(loyaltyProgramsTable.id, transaction.programId))
      .limit(1),
  ]);

  return {
    id: transaction.id,
    customerId: transaction.customerId,
    customerName: customer ? `${customer.firstName} ${customer.lastName}`.trim() : "Customer",
    programId: transaction.programId,
    programName: program?.name ?? "Loyalty program",
    type: transaction.type,
    amount: Number(transaction.amount),
    currency: transaction.currency,
    stampsAdded: transaction.stampsAdded,
    pointsAdded: transaction.pointsAdded,
    createdAt: transaction.createdAt.toISOString(),
  };
}

router.get("/session", async (_req, res): Promise<void> => {
  await ensureDemoData();
  const business = await businessDto();
  res.json(
    GetSessionResponse.parse({
      authenticated: true,
      user: {
        id: demoIds.profile,
        name: "Sophie Gruber",
        email: "sophie@qreward.demo",
        avatarUrl: null,
      },
      business,
      role: "OWNER",
    }),
  );
});

router.post("/onboarding", async (req, res): Promise<void> => {
  const parsed = CompleteOnboardingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const input = parsed.data;
  const existingBusiness = await getDemoBusiness();
  if (existingBusiness) {
    const [business, program] = await Promise.all([
      db
        .update(businessesTable)
        .set({
          name: input.businessName,
          country: input.country,
          currency: input.currency,
          timezone: input.timezone,
        })
        .where(eq(businessesTable.id, demoIds.business))
        .returning()
        .then(([updated]) => updated),
      db
        .update(loyaltyProgramsTable)
        .set({
          name: input.programName,
          description: `A loyalty program for ${input.businessName}.`,
          type: input.programType,
          status: "DRAFT",
          rewardDescription: input.rewardDescription,
          stampTarget: input.stampTarget ?? null,
        })
        .where(
          and(
            eq(loyaltyProgramsTable.id, demoIds.program),
            eq(loyaltyProgramsTable.businessId, demoIds.business),
          ),
        )
        .returning()
        .then(([updated]) => updated),
    ]);

    if (!business || !program) {
      res.status(500).json({ error: "The demo workspace could not be prepared." });
      return;
    }

    res.json({
      business: (await businessDto()) ?? business,
      program: await programDto(program),
      nextStep: "DESIGN_CARD",
    });
    return;
  }

  const [business] = await db
    .insert(businessesTable)
    .values({
      name: input.businessName,
      slug: `${input.businessName.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${randomUUID().slice(0, 6)}`,
      country: input.country,
      currency: input.currency,
      timezone: input.timezone,
      subscriptionStatus: "TRIALING",
    })
    .returning();

  const [program] = await db
    .insert(loyaltyProgramsTable)
    .values({
      businessId: business.id,
      name: input.programName,
      description: `A loyalty program for ${input.businessName}.`,
      type: input.programType,
      status: "DRAFT",
      primaryColor: "#7056E8",
      secondaryColor: "#A89BFF",
      backgroundColor: "#F5F2FF",
      rewardDescription: input.rewardDescription,
      stampTarget: input.stampTarget ?? null,
    })
    .returning();

  res.status(201).json({
    business: {
      ...business,
      logoUrl: business.logoUrl,
      locations: 0,
      activePrograms: 0,
    },
    program: await programDto(program),
    nextStep: "DESIGN_CARD",
  });
});

router.get("/business", async (_req, res): Promise<void> => {
  await ensureDemoData();
  const business = await businessDto();
  if (!business) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  res.json(GetBusinessResponse.parse(business));
});

router.patch("/business", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = UpdateBusinessBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [updated] = await db
    .update(businessesTable)
    .set(parsed.data)
    .where(eq(businessesTable.id, demoIds.business))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  res.json(GetBusinessResponse.parse(await businessDto()));
});

router.get("/dashboard/summary", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = GetDashboardSummaryQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [[customerStats], [transactionStats], [rewardStats], [programStats]] =
    await Promise.all([
      db
        .select({ value: count() })
        .from(customersTable)
        .where(eq(customersTable.businessId, demoIds.business)),
      db
        .select({
          visits: count(),
          revenue: sql<string>`coalesce(sum(${transactionsTable.amount}), 0)`,
        })
        .from(transactionsTable)
        .where(eq(transactionsTable.businessId, demoIds.business)),
      db
        .select({ value: count() })
        .from(rewardsTable)
        .innerJoin(customersTable, eq(rewardsTable.customerId, customersTable.id))
        .where(
          and(
            eq(customersTable.businessId, demoIds.business),
            eq(rewardsTable.status, "REDEEMED"),
          ),
        ),
      db
        .select({ value: count() })
        .from(loyaltyProgramsTable)
        .where(
          and(
            eq(loyaltyProgramsTable.businessId, demoIds.business),
            eq(loyaltyProgramsTable.active, true),
          ),
        ),
    ]);

  res.json({
    totalCustomers: Number(customerStats.value),
    visits: Number(transactionStats.visits),
    returningCustomers: 4,
    rewardsRedeemed: Number(rewardStats.value),
    recordedRevenue: Number(transactionStats.revenue),
    activePrograms: Number(programStats.value),
    customerGrowth: 12.4,
    visitGrowth: 8.2,
    rewardGrowth: 16.8,
    revenueGrowth: 9.6,
  });
});

router.get("/dashboard/activity", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = GetDashboardActivityQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const transactions = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.businessId, demoIds.business))
    .orderBy(desc(transactionsTable.createdAt))
    .limit(parsed.data.limit);
  const items = await Promise.all(
    transactions.map(async (transaction) => {
      const dto = await transactionDto(transaction);
      return {
        id: dto.id,
        type: "PURCHASE" as const,
        title: `${dto.customerName} visited`,
        description: `${dto.stampsAdded} stamp added to ${dto.programName}`,
        customerName: dto.customerName,
        amount: dto.amount,
        createdAt: dto.createdAt,
      };
    }),
  );
  res.json(items);
});

router.get("/programs", async (_req, res): Promise<void> => {
  await ensureDemoData();
  const programs = await db
    .select()
    .from(loyaltyProgramsTable)
    .where(eq(loyaltyProgramsTable.businessId, demoIds.business))
    .orderBy(desc(loyaltyProgramsTable.createdAt));
  res.json(ListProgramsResponse.parse(await Promise.all(programs.map(programDto))));
});

router.post("/programs", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = CreateProgramBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [program] = await db
    .insert(loyaltyProgramsTable)
    .values({
      ...parsed.data,
      businessId: demoIds.business,
      status: "DRAFT",
    })
    .returning();
  res.status(201).json(await programDto(program));
});

router.get("/programs/:id", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = GetProgramParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [program] = await db
    .select()
    .from(loyaltyProgramsTable)
    .where(
      and(
        eq(loyaltyProgramsTable.id, parsed.data.id),
        eq(loyaltyProgramsTable.businessId, demoIds.business),
      ),
    )
    .limit(1);
  if (!program) {
    res.status(404).json({ error: "Program not found" });
    return;
  }
  res.json(await programDto(program));
});

router.patch("/programs/:id", async (req, res): Promise<void> => {
  await ensureDemoData();
  const params = UpdateProgramParams.safeParse(req.params);
  const body = UpdateProgramBody.safeParse(req.body);
  if (!params.success || !body.success) {
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
    } else {
      res.status(400).json({ error: body.error?.message ?? "Invalid program update." });
    }
    return;
  }
  const [program] = await db
    .update(loyaltyProgramsTable)
    .set(body.data)
    .where(
      and(
        eq(loyaltyProgramsTable.id, params.data.id),
        eq(loyaltyProgramsTable.businessId, demoIds.business),
      ),
    )
    .returning();
  if (!program) {
    res.status(404).json({ error: "Program not found" });
    return;
  }
  res.json(await programDto(program));
});

router.get("/customers", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = ListCustomersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { search, status, page, pageSize } = parsed.data;
  const conditions: SQL[] = [eq(customersTable.businessId, demoIds.business)];
  if (search) {
    const searchCondition = or(
      ilike(customersTable.firstName, `%${search}%`),
      ilike(customersTable.lastName, `%${search}%`),
      ilike(customersTable.email, `%${search}%`),
    );
    if (searchCondition) {
      conditions.push(searchCondition);
    }
  }
  if (status !== "all") {
    conditions.push(
      eq(customersTable.status, status.toUpperCase() as "ACTIVE" | "INACTIVE" | "NEW" | "RETURNING"),
    );
  }
  const [items, [{ value: total }]] = await Promise.all([
    db
      .select()
      .from(customersTable)
      .where(and(...conditions))
      .orderBy(desc(customersTable.createdAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize),
    db
      .select({ value: count() })
      .from(customersTable)
      .where(and(...conditions)),
  ]);
  res.json({
    items: items.map(customerDto),
    page,
    pageSize,
    total: Number(total),
  });
});

router.post("/customers", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = CreateCustomerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [customer] = await db
    .insert(customersTable)
    .values({
      ...parsed.data,
      businessId: demoIds.business,
      secureToken: randomUUID(),
      status: "NEW",
    })
    .returning();
  res.status(201).json(customerDto(customer));
});

router.get("/customers/:id", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = GetCustomerParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [customer] = await db
    .select()
    .from(customersTable)
    .where(
      and(
        eq(customersTable.id, parsed.data.id),
        eq(customersTable.businessId, demoIds.business),
      ),
    )
    .limit(1);
  if (!customer) {
    res.status(404).json({ error: "Customer not found" });
    return;
  }
  const [programs, rewards, transactions] = await Promise.all([
    db
      .select({
        programId: customerProgramsTable.programId,
        programName: loyaltyProgramsTable.name,
        balance: customerProgramsTable.balance,
        stamps: customerProgramsTable.stamps,
        points: customerProgramsTable.points,
      })
      .from(customerProgramsTable)
      .innerJoin(
        loyaltyProgramsTable,
        eq(customerProgramsTable.programId, loyaltyProgramsTable.id),
      )
      .where(eq(customerProgramsTable.customerId, customer.id)),
    db.select().from(rewardsTable).where(eq(rewardsTable.customerId, customer.id)),
    db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.customerId, customer.id))
      .orderBy(desc(transactionsTable.createdAt))
      .limit(20),
  ]);

  res.json({
    ...customerDto(customer),
    programs,
    rewards: rewards.map(rewardDto),
    transactions: await Promise.all(transactions.map(transactionDto)),
  });
});

router.get("/transactions", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = ListTransactionsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const transactions = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.businessId, demoIds.business))
    .orderBy(desc(transactionsTable.createdAt))
    .limit(parsed.data.limit);
  res.json(await Promise.all(transactions.map(transactionDto)));
});

router.post("/transactions", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = CreateTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const result = await db.transaction(async (tx) => {
    const [[customer], [program], [balance]] = await Promise.all([
      tx
        .select()
        .from(customersTable)
        .where(
          and(
            eq(customersTable.id, parsed.data.customerId),
            eq(customersTable.businessId, demoIds.business),
          ),
        )
        .limit(1),
      tx
        .select()
        .from(loyaltyProgramsTable)
        .where(
          and(
            eq(loyaltyProgramsTable.id, parsed.data.programId),
            eq(loyaltyProgramsTable.businessId, demoIds.business),
          ),
        )
        .limit(1),
      tx
        .select()
        .from(customerProgramsTable)
        .where(
          and(
            eq(customerProgramsTable.customerId, parsed.data.customerId),
            eq(customerProgramsTable.programId, parsed.data.programId),
          ),
        )
        .limit(1),
    ]);
    if (!customer || !program || !balance) {
      throw new Error("Customer, program, or balance not found");
    }

    const target = program.stampTarget ?? Number.MAX_SAFE_INTEGER;
    const nextStamps = balance.stamps + parsed.data.stampsAdded;
    const rewardEarned = nextStamps >= target;
    const nextBalance = rewardEarned ? nextStamps - target : nextStamps;

    const [transaction] = await tx
      .insert(transactionsTable)
      .values({
        businessId: demoIds.business,
        customerId: customer.id,
        programId: program.id,
        employeeId: demoIds.profile,
        type: "PURCHASE",
        amount: String(parsed.data.amount),
        currency: "EUR",
        stampsAdded: parsed.data.stampsAdded,
        pointsAdded: parsed.data.pointsAdded,
      })
      .returning();

    const [nextProgramBalance] = await tx
      .update(customerProgramsTable)
      .set({
        balance: nextBalance,
        stamps: nextBalance,
        points: balance.points + parsed.data.pointsAdded,
      })
      .where(eq(customerProgramsTable.id, balance.id))
      .returning();

    await tx
      .update(customersTable)
      .set({
        totalVisits: customer.totalVisits + 1,
        totalSpend: String(Number(customer.totalSpend) + parsed.data.amount),
        lastVisitAt: new Date(),
        status: "RETURNING",
      })
      .where(eq(customersTable.id, customer.id));

    let reward = null;
    if (rewardEarned) {
      [reward] = await tx
        .insert(rewardsTable)
        .values({
          customerId: customer.id,
          programId: program.id,
          name: program.rewardDescription,
          description: `Unlocked after reaching ${target} stamps.`,
          status: "AVAILABLE",
          transactionId: transaction.id,
        })
        .returning();
    }

    await tx.insert(analyticsEventsTable).values({
      businessId: demoIds.business,
      customerId: customer.id,
      programId: program.id,
      eventType: rewardEarned ? "REWARD_EARNED" : "STAMP_ADDED",
      metadata: { amount: parsed.data.amount },
    });

    return { transaction, nextProgramBalance, reward };
  });

  res.status(201).json({
    transaction: await transactionDto(result.transaction),
    balance: {
      programId: parsed.data.programId,
      programName: (await getDemoProgram())?.name ?? "Loyalty program",
      balance: result.nextProgramBalance.balance,
      stamps: result.nextProgramBalance.stamps,
      points: result.nextProgramBalance.points,
    },
    reward: result.reward ? rewardDto(result.reward) : null,
  });
});

router.post("/scanner/validate", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = ValidateScanBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [customer] = await db
    .select()
    .from(customersTable)
    .where(
      and(
        eq(customersTable.secureToken, parsed.data.token),
        eq(customersTable.businessId, demoIds.business),
      ),
    )
    .limit(1);
  const program = await getDemoProgram();
  if (!customer || !program) {
    res.status(400).json({ error: "This QR code is not valid for this business." });
    return;
  }
  const [balance] = await db
    .select()
    .from(customerProgramsTable)
    .where(
      and(
        eq(customerProgramsTable.customerId, customer.id),
        eq(customerProgramsTable.programId, program.id),
      ),
    )
    .limit(1);
  if (!balance) {
    res.status(400).json({ error: "Customer is not enrolled in this program." });
    return;
  }
  res.json({
    customer: customerDto(customer),
    program: await programDto(program),
    balance: {
      programId: program.id,
      programName: program.name,
      balance: balance.balance,
      stamps: balance.stamps,
      points: balance.points,
    },
  });
});

router.post("/rewards/:id/redeem", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = RedeemRewardParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [reward] = await db
    .update(rewardsTable)
    .set({ status: "REDEEMED", redeemedAt: new Date() })
    .where(
      and(
        eq(rewardsTable.id, parsed.data.id),
        eq(rewardsTable.status, "AVAILABLE"),
      ),
    )
    .returning();
  if (!reward) {
    res.status(409).json({ error: "Reward is no longer available." });
    return;
  }
  res.json(rewardDto(reward));
});

router.get("/analytics", async (req, res): Promise<void> => {
  await ensureDemoData();
  const parsed = GetAnalyticsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [events, transactions] = await Promise.all([
    db
      .select()
      .from(analyticsEventsTable)
      .where(eq(analyticsEventsTable.businessId, demoIds.business)),
    db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.businessId, demoIds.business)),
  ]);
  const labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const makeSeries = (multiplier: number) =>
    labels.map((label, index) => ({
      label,
      value: Math.round((events.length + transactions.length + index + 1) * multiplier),
    }));
  res.json({
    range: parsed.data.range,
    customerGrowth: makeSeries(1.2),
    visits: makeSeries(2.4),
    revenue: makeSeries(9.5),
    redemptions: makeSeries(0.6),
  });
});

export default router;