import { and, eq } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  businessMembersTable,
  businessesTable,
  customerProgramsTable,
  customersTable,
  loyaltyProgramsTable,
  locationsTable,
  profilesTable,
  rewardsTable,
  transactionsTable,
} from "@workspace/db";

export const demoIds = {
  business: "11111111-1111-4111-8111-111111111111",
  location: "22222222-2222-4222-8222-222222222222",
  profile: "33333333-3333-4333-8333-333333333333",
  program: "44444444-4444-4444-8444-444444444444",
  customers: [
    "55555555-5555-4555-8555-555555555551",
    "55555555-5555-4555-8555-555555555552",
    "55555555-5555-4555-8555-555555555553",
    "55555555-5555-4555-8555-555555555554",
    "55555555-5555-4555-8555-555555555555",
    "55555555-5555-4555-8555-555555555556",
  ],
} as const;

const customers = [
  ["Maya", "Kowalski", "maya@example.com", "qreward-demo-maya"],
  ["Jonas", "Huber", "jonas@example.com", "qreward-demo-jonas"],
  ["Sofia", "Nagy", "sofia@example.com", "qreward-demo-sofia"],
  ["Leo", "Martin", "leo@example.com", "qreward-demo-leo"],
  ["Ava", "Rossi", "ava@example.com", "qreward-demo-ava"],
  ["Noah", "Berger", "noah@example.com", "qreward-demo-noah"],
] as const;

export async function ensureDemoData(): Promise<void> {
  const [existing] = await db
    .select({ id: businessesTable.id })
    .from(businessesTable)
    .where(eq(businessesTable.id, demoIds.business))
    .limit(1);

  if (existing) {
    return;
  }

  await db.transaction(async (tx) => {
    await tx.insert(businessesTable).values({
      id: demoIds.business,
      name: "QReward Demo Café",
      slug: "qreward-demo-cafe",
      email: "hello@qreward.demo",
      city: "Vienna",
      country: "AT",
      timezone: "Europe/Vienna",
      currency: "EUR",
      subscriptionStatus: "TRIALING",
    });

    await tx.insert(locationsTable).values({
      id: demoIds.location,
      businessId: demoIds.business,
      name: "Mariahilfer Straße",
      address: "Mariahilfer Straße 42",
      city: "Vienna",
      postalCode: "1070",
      country: "AT",
      timezone: "Europe/Vienna",
    });

    await tx.insert(profilesTable).values({
      id: demoIds.profile,
      authUserId: "demo-owner",
      name: "Sophie Gruber",
      email: "sophie@qreward.demo",
    });

    await tx.insert(businessMembersTable).values({
      businessId: demoIds.business,
      profileId: demoIds.profile,
      role: "OWNER",
      locationId: demoIds.location,
    });

    await tx.insert(loyaltyProgramsTable).values({
      id: demoIds.program,
      businessId: demoIds.business,
      locationId: demoIds.location,
      name: "Coffee Stamp Card",
      description: "A little thank you for every coffee run.",
      type: "STAMP",
      active: true,
      status: "PUBLISHED",
      primaryColor: "#7056E8",
      secondaryColor: "#A89BFF",
      backgroundColor: "#F5F2FF",
      rewardDescription: "Free coffee of your choice",
      stampTarget: 10,
    });

    for (const [index, customer] of customers.entries()) {
      const customerId = demoIds.customers[index];
      const stamps = [7, 4, 9, 2, 6, 3][index];
      await tx.insert(customersTable).values({
        id: customerId,
        businessId: demoIds.business,
        firstName: customer[0],
        lastName: customer[1],
        email: customer[2],
        marketingConsent: true,
        status: stamps > 5 ? "RETURNING" : "ACTIVE",
        totalVisits: stamps + 2,
        totalSpend: String((stamps + 2) * 4.5),
        lastVisitAt: new Date(Date.now() - index * 86_400_000),
        secureToken: customer[3],
      });

      await tx.insert(customerProgramsTable).values({
        customerId,
        programId: demoIds.program,
        balance: stamps,
        stamps,
        points: 0,
      });

      if (index === 2) {
        await tx.insert(rewardsTable).values({
          customerId,
          programId: demoIds.program,
          name: "Free coffee",
          description: "Your next coffee is on us.",
          status: "AVAILABLE",
        });
      }
    }

    const transactionRows = [
      [0, 4.5, 1],
      [2, 5.2, 1],
      [1, 4.5, 1],
      [4, 4.2, 1],
      [3, 6.5, 1],
      [0, 4.5, 1],
    ] as const;

    for (const [index, amount, stampsAdded] of transactionRows) {
      await tx.insert(transactionsTable).values({
        businessId: demoIds.business,
        locationId: demoIds.location,
        customerId: demoIds.customers[index],
        programId: demoIds.program,
        employeeId: demoIds.profile,
        type: "PURCHASE",
        amount: String(amount),
        currency: "EUR",
        stampsAdded,
        pointsAdded: 0,
        createdAt: new Date(Date.now() - index * 3_600_000),
      });
    }
  });
}

export async function getDemoBusiness() {
  const [business] = await db
    .select()
    .from(businessesTable)
    .where(eq(businessesTable.id, demoIds.business))
    .limit(1);
  return business;
}

export async function getDemoProgram() {
  const [program] = await db
    .select()
    .from(loyaltyProgramsTable)
    .where(
      and(
        eq(loyaltyProgramsTable.id, demoIds.program),
        eq(loyaltyProgramsTable.businessId, demoIds.business),
      ),
    )
    .limit(1);
  return program;
}