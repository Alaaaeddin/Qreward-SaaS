import { relations } from "drizzle-orm";
import {
  boolean,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const memberRoleEnum = pgEnum("member_role", [
  "OWNER",
  "ADMIN",
  "MANAGER",
  "EMPLOYEE",
]);

export const programTypeEnum = pgEnum("program_type", [
  "STAMP",
  "POINTS",
  "CASHBACK",
  "REWARD",
  "MEMBERSHIP",
  "DISCOUNT",
  "COUPON",
  "MULTIPASS",
  "GIFT_CARD",
]);

export const programStatusEnum = pgEnum("program_status", [
  "DRAFT",
  "PUBLISHED",
  "ARCHIVED",
]);

export const customerStatusEnum = pgEnum("customer_status", [
  "ACTIVE",
  "INACTIVE",
  "NEW",
  "RETURNING",
]);

export const rewardStatusEnum = pgEnum("reward_status", [
  "AVAILABLE",
  "REDEEMED",
  "EXPIRED",
]);

export const transactionTypeEnum = pgEnum("transaction_type", [
  "PURCHASE",
  "STAMP",
  "POINTS",
  "REDEMPTION",
]);

export const businessesTable = pgTable(
  "businesses",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: text("name").notNull(),
    slug: text("slug").notNull(),
    logoUrl: text("logo_url"),
    email: text("email"),
    phone: text("phone"),
    website: text("website"),
    city: text("city"),
    country: text("country").notNull().default("AT"),
    timezone: text("timezone").notNull().default("Europe/Vienna"),
    currency: text("currency").notNull().default("EUR"),
    subscriptionStatus: text("subscription_status")
      .notNull()
      .default("TRIALING"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [uniqueIndex("businesses_slug_idx").on(table.slug)],
);

export const locationsTable = pgTable("locations", {
  id: uuid("id").defaultRandom().primaryKey(),
  businessId: uuid("business_id")
    .notNull()
    .references(() => businessesTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  address: text("address"),
  city: text("city"),
  postalCode: text("postal_code"),
  country: text("country"),
  timezone: text("timezone"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const profilesTable = pgTable(
  "profiles",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    authUserId: text("auth_user_id").notNull(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    avatarUrl: text("avatar_url"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [uniqueIndex("profiles_auth_user_id_idx").on(table.authUserId)],
);

export const businessMembersTable = pgTable(
  "business_members",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    businessId: uuid("business_id")
      .notNull()
      .references(() => businessesTable.id, { onDelete: "cascade" }),
    profileId: uuid("profile_id")
      .notNull()
      .references(() => profilesTable.id, { onDelete: "cascade" }),
    role: memberRoleEnum("role").notNull().default("OWNER"),
    locationId: uuid("location_id").references(() => locationsTable.id, {
      onDelete: "set null",
    }),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("business_members_business_profile_idx").on(
      table.businessId,
      table.profileId,
    ),
  ],
);

export const customersTable = pgTable(
  "customers",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    businessId: uuid("business_id")
      .notNull()
      .references(() => businessesTable.id, { onDelete: "cascade" }),
    firstName: text("first_name").notNull(),
    lastName: text("last_name").notNull().default(""),
    email: text("email"),
    phone: text("phone"),
    dateOfBirth: text("date_of_birth"),
    marketingConsent: boolean("marketing_consent").notNull().default(false),
    status: customerStatusEnum("status").notNull().default("NEW"),
    totalVisits: integer("total_visits").notNull().default(0),
    totalSpend: numeric("total_spend", { precision: 12, scale: 2 })
      .notNull()
      .default("0"),
    lastVisitAt: timestamp("last_visit_at", { withTimezone: true }),
    secureToken: text("secure_token").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("customers_secure_token_idx").on(table.secureToken),
    uniqueIndex("customers_business_email_idx").on(table.businessId, table.email),
  ],
);

export const pushSubscriptionsTable = pgTable(
  "push_subscriptions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    customerId: uuid("customer_id")
      .notNull()
      .references(() => customersTable.id, { onDelete: "cascade" }),
    endpoint: text("endpoint").notNull(),
    p256dh: text("p256dh").notNull(),
    auth: text("auth").notNull(),
    userAgent: text("user_agent"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("push_subscriptions_endpoint_idx").on(table.endpoint),
  ],
);

export const loyaltyProgramsTable = pgTable("loyalty_programs", {
  id: uuid("id").defaultRandom().primaryKey(),
  businessId: uuid("business_id")
    .notNull()
    .references(() => businessesTable.id, { onDelete: "cascade" }),
  locationId: uuid("location_id").references(() => locationsTable.id, {
    onDelete: "set null",
  }),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  type: programTypeEnum("type").notNull().default("STAMP"),
  active: boolean("active").notNull().default(true),
  status: programStatusEnum("status").notNull().default("DRAFT"),
  primaryColor: text("primary_color").notNull().default("#6D4AFF"),
  secondaryColor: text("secondary_color").notNull().default("#B9AAFF"),
  backgroundColor: text("background_color").notNull().default("#F6F5FF"),
  rewardDescription: text("reward_description").notNull().default(""),
  stampTarget: integer("stamp_target"),
  pointsTarget: integer("points_target"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const programRulesTable = pgTable("program_rules", {
  id: uuid("id").defaultRandom().primaryKey(),
  programId: uuid("program_id")
    .notNull()
    .references(() => loyaltyProgramsTable.id, { onDelete: "cascade" }),
  stampTarget: integer("stamp_target"),
  pointsTarget: integer("points_target"),
  cashbackPercentage: numeric("cashback_percentage", {
    precision: 5,
    scale: 2,
  }),
  rewardDescription: text("reward_description"),
  minimumPurchase: numeric("minimum_purchase", { precision: 12, scale: 2 }),
  expirationDays: integer("expiration_days"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const customerProgramsTable = pgTable(
  "customer_programs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    customerId: uuid("customer_id")
      .notNull()
      .references(() => customersTable.id, { onDelete: "cascade" }),
    programId: uuid("program_id")
      .notNull()
      .references(() => loyaltyProgramsTable.id, { onDelete: "cascade" }),
    balance: integer("balance").notNull().default(0),
    stamps: integer("stamps").notNull().default(0),
    points: integer("points").notNull().default(0),
    membershipStatus: text("membership_status"),
    joinedAt: timestamp("joined_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("customer_programs_customer_program_idx").on(
      table.customerId,
      table.programId,
    ),
  ],
);

export const rewardsTable = pgTable("rewards", {
  id: uuid("id").defaultRandom().primaryKey(),
  programId: uuid("program_id")
    .notNull()
    .references(() => loyaltyProgramsTable.id, { onDelete: "cascade" }),
  customerId: uuid("customer_id")
    .notNull()
    .references(() => customersTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description").notNull(),
  status: rewardStatusEnum("status").notNull().default("AVAILABLE"),
  earnedAt: timestamp("earned_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  redeemedAt: timestamp("redeemed_at", { withTimezone: true }),
  transactionId: uuid("transaction_id"),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
});

export const transactionsTable = pgTable("transactions", {
  id: uuid("id").defaultRandom().primaryKey(),
  businessId: uuid("business_id")
    .notNull()
    .references(() => businessesTable.id, { onDelete: "cascade" }),
  locationId: uuid("location_id").references(() => locationsTable.id, {
    onDelete: "set null",
  }),
  customerId: uuid("customer_id")
    .notNull()
    .references(() => customersTable.id, { onDelete: "cascade" }),
  programId: uuid("program_id")
    .notNull()
    .references(() => loyaltyProgramsTable.id, { onDelete: "cascade" }),
  employeeId: uuid("employee_id").references(() => profilesTable.id, {
    onDelete: "set null",
  }),
  type: transactionTypeEnum("type").notNull().default("PURCHASE"),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull().default("0"),
  currency: text("currency").notNull().default("EUR"),
  stampsAdded: integer("stamps_added").notNull().default(0),
  pointsAdded: integer("points_added").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const analyticsEventsTable = pgTable("analytics_events", {
  id: uuid("id").defaultRandom().primaryKey(),
  businessId: uuid("business_id")
    .notNull()
    .references(() => businessesTable.id, { onDelete: "cascade" }),
  locationId: uuid("location_id").references(() => locationsTable.id, {
    onDelete: "set null",
  }),
  customerId: uuid("customer_id").references(() => customersTable.id, {
    onDelete: "set null",
  }),
  programId: uuid("program_id").references(() => loyaltyProgramsTable.id, {
    onDelete: "set null",
  }),
  eventType: text("event_type").notNull(),
  metadata: jsonb("metadata").$type<Record<string, unknown>>(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const auditLogsTable = pgTable("audit_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  businessId: uuid("business_id").references(() => businessesTable.id, {
    onDelete: "cascade",
  }),
  userId: uuid("user_id").references(() => profilesTable.id, {
    onDelete: "set null",
  }),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: uuid("entity_id"),
  metadata: jsonb("metadata").$type<Record<string, unknown>>(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const businessesRelations = relations(businessesTable, ({ many }) => ({
  locations: many(locationsTable),
  members: many(businessMembersTable),
  customers: many(customersTable),
  programs: many(loyaltyProgramsTable),
  transactions: many(transactionsTable),
  analyticsEvents: many(analyticsEventsTable),
}));

export const locationsRelations = relations(locationsTable, ({ one, many }) => ({
  business: one(businessesTable, {
    fields: [locationsTable.businessId],
    references: [businessesTable.id],
  }),
  members: many(businessMembersTable),
}));

export const profilesRelations = relations(profilesTable, ({ many }) => ({
  memberships: many(businessMembersTable),
}));

export const businessMembersRelations = relations(
  businessMembersTable,
  ({ one }) => ({
    business: one(businessesTable, {
      fields: [businessMembersTable.businessId],
      references: [businessesTable.id],
    }),
    profile: one(profilesTable, {
      fields: [businessMembersTable.profileId],
      references: [profilesTable.id],
    }),
    location: one(locationsTable, {
      fields: [businessMembersTable.locationId],
      references: [locationsTable.id],
    }),
  }),
);

export const customersRelations = relations(customersTable, ({ one, many }) => ({
  business: one(businessesTable, {
    fields: [customersTable.businessId],
    references: [businessesTable.id],
  }),
  programs: many(customerProgramsTable),
  rewards: many(rewardsTable),
  transactions: many(transactionsTable),
  pushSubscriptions: many(pushSubscriptionsTable),
}));

export const pushSubscriptionsRelations = relations(
  pushSubscriptionsTable,
  ({ one }) => ({
    customer: one(customersTable, {
      fields: [pushSubscriptionsTable.customerId],
      references: [customersTable.id],
    }),
  }),
);

export const loyaltyProgramsRelations = relations(
  loyaltyProgramsTable,
  ({ one, many }) => ({
    business: one(businessesTable, {
      fields: [loyaltyProgramsTable.businessId],
      references: [businessesTable.id],
    }),
    location: one(locationsTable, {
      fields: [loyaltyProgramsTable.locationId],
      references: [locationsTable.id],
    }),
    rules: many(programRulesTable),
    customers: many(customerProgramsTable),
    rewards: many(rewardsTable),
    transactions: many(transactionsTable),
  }),
);

export const programRulesRelations = relations(programRulesTable, ({ one }) => ({
  program: one(loyaltyProgramsTable, {
    fields: [programRulesTable.programId],
    references: [loyaltyProgramsTable.id],
  }),
}));

export const customerProgramsRelations = relations(
  customerProgramsTable,
  ({ one }) => ({
    customer: one(customersTable, {
      fields: [customerProgramsTable.customerId],
      references: [customersTable.id],
    }),
    program: one(loyaltyProgramsTable, {
      fields: [customerProgramsTable.programId],
      references: [loyaltyProgramsTable.id],
    }),
  }),
);

export const rewardsRelations = relations(rewardsTable, ({ one }) => ({
  customer: one(customersTable, {
    fields: [rewardsTable.customerId],
    references: [customersTable.id],
  }),
  program: one(loyaltyProgramsTable, {
    fields: [rewardsTable.programId],
    references: [loyaltyProgramsTable.id],
  }),
}));

export const transactionsRelations = relations(transactionsTable, ({ one }) => ({
  business: one(businessesTable, {
    fields: [transactionsTable.businessId],
    references: [businessesTable.id],
  }),
  customer: one(customersTable, {
    fields: [transactionsTable.customerId],
    references: [customersTable.id],
  }),
  program: one(loyaltyProgramsTable, {
    fields: [transactionsTable.programId],
    references: [loyaltyProgramsTable.id],
  }),
  employee: one(profilesTable, {
    fields: [transactionsTable.employeeId],
    references: [profilesTable.id],
  }),
}));

export const insertBusinessSchema = createInsertSchema(businessesTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const insertProgramSchema = createInsertSchema(loyaltyProgramsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const insertCustomerSchema = createInsertSchema(customersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const insertPushSubscriptionSchema = createInsertSchema(
  pushSubscriptionsTable,
).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type Business = typeof businessesTable.$inferSelect;
export type LoyaltyProgram = typeof loyaltyProgramsTable.$inferSelect;
export type Customer = typeof customersTable.$inferSelect;
export type PushSubscription = typeof pushSubscriptionsTable.$inferSelect;
export type CustomerProgram = typeof customerProgramsTable.$inferSelect;
export type Transaction = typeof transactionsTable.$inferSelect;
export type Reward = typeof rewardsTable.$inferSelect;
export type InsertBusiness = z.infer<typeof insertBusinessSchema>;
export type InsertProgram = z.infer<typeof insertProgramSchema>;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type InsertPushSubscription = z.infer<typeof insertPushSubscriptionSchema>;